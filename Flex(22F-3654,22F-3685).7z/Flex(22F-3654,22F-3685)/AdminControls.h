#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include <ctime>

using namespace std;

//Contains Addresses
struct Residence {
	string* state;
	string* city;
	string* area;
	string* houseNo;
	int* zip;
};
//Registeration
class Registeration {
	string* fName;
	string* lName;
	string* department;
	string* gender;
	string* contactNo;
	string* qualification;
	string* regDate;
	Residence address;


public:
	Registeration();
	~Registeration();

	void setFn();
	void setLn();
	void setDn();
	void setG();
	void setCn();
	void setQ();
	void setRd();
	void setAd();
	string getFn();
	string getLn();
	string getDn();
	string getG();
	string getCn();
	string getQ();
	string getRd();
	void getAd();
	string getAds();
	string getAdc();
	string getAda();
	string getAdh();
	int getAdz();
	string AddZero(int);

};
//Specific Registerations fo Students
class TeacherReg : public Registeration {
	string* TregNo;
	string* username;
	string* password;
	string* Course;
	int interest,CS, SS, B, EE, SE;
public:
	TeacherReg();
	~TeacherReg();
	void Cstore();
	void Tcount();
	void setTn();
	void setTn(string roll);
	void setUn();
	void setPs();
	void setInterest();
	int getInterest();
	string getTn();
	string getUn();
	string getPs();
	void TeachCourse();
};
//Specific Registerations for Teachers
class StudentReg : public Registeration {
	string* SregNo;
	string* bloodGroup;
	string* pass;
	bool feeStatus;
	int* course;
	int* marks;
public:
	StudentReg();
	~StudentReg();
	void setSn();
	void setSn(string roll);
	void setBg();
	void setFs();
	void setM();
	void setPass();
	void Login();
	void setCourse();
	void StudyCourse();
	string getCourse();
	string getSn();
	string getBg();
	string getPass();
	bool getFs();
	int getM();

};
// All the admin Attributes
class AdminControls {
	int noOfStudents;
	int noOfTeachers;
public:
	AdminControls();
	~AdminControls();

	StudentReg* stud = new StudentReg[noOfStudents];
	TeacherReg* teach = new TeacherReg[noOfTeachers];

	void newStudent();
	void newStudent(string roll);
	void newTeacher();
	void newTeacher(string roll);
	void fileHandlingStd();
	void fileHandlingTch();
	void Register();
	void edit();
	void ViewS();
	void ViewT();
	void assignStd_Tch();

};

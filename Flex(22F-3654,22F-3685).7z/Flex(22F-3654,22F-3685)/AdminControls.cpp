#include "AdminControls.h"

//Global Declarations
bool Tchk = false, Schk = false;
int arr[6] = {};
//constructor
Registeration::Registeration()
{
	this->fName = new string("");
	this->lName = new string("");
	this->department = new string("");
	this->gender = new string("");
	this->contactNo = new string("");
	this->qualification = new string("");
	this->regDate = new string("");
	this->address.state = new string("");
	this->address.city = new string("");
	this->address.area = new string("");
	this->address.houseNo = new string("");
	this->address.zip = new int(0);
}
//destructor
Registeration::~Registeration()
{
	delete fName;
	delete lName;
	delete department;
	delete gender;
	delete contactNo;
	delete qualification;
	delete regDate;
	delete address.state;
	delete address.city;
	delete address.area;
	delete address.houseNo;
	delete address.zip;
}
//Setters
//First Name
void Registeration::setFn()
{
	cin.ignore();
	fName = new string();
	system("cls");
	cout << "Enter First Name: ";
	getline(cin, *fName);
}
//Last Name
void Registeration::setLn()
{
	this->lName = new string();
	cout << "Enter Last Name: "; getline(cin, *lName);
}
//Department Name
void Registeration::setDn()
{
	int choiceCourse,check=0;
	do {
		if (check != 0) cout <<endl<< "INCORECT INPUT!" << endl;
		cout << "1- Computer Science\n2- Electric Engeneering\n3- Software Engineering\n"
			<< "4- Business\n5- Social Sciences\nEnter Number: "; cin >> choiceCourse; ++check; system("cls");
	} while (!(choiceCourse>=1 && choiceCourse<=5));
	check = 0;
	department = new string();

	switch (choiceCourse) {
	case 1:
		*department = "Computer Science";
		break;
	case 2:
		*department = "Electric Engeneering";
		break;
	case 3:
		*department = "Software Engeneering";
		break;
	case 4:
		*department = "Business";
		break;
	case 5:
		*department = "Social Sciences";
		break;
	}
}
//Gender
void Registeration::setG()
{
	int check = 0;
	char temp;
	do {
		if (check != 0) cout << "\nINCORRECT INPUT!\n";
		cout << "M- Male / F- Female\n Enter Charachter: "; cin >> temp; check++;
	} while (temp != 'M' && temp != 'm' && temp != 'F' && temp != 'f');
	check = 0;
	gender = new string();

	switch (temp) {
	case 'M':
	case'm':
		*this->gender = "Male";
		break;
	case 'F':
	case'f':
		*this->gender = "Female";
		break;
	}
}
//Contact
void Registeration::setCn()
{
	system("cls");
	contactNo = new string();
	cout << "For Example = '0321-1234567'\nEnter Contact No:"; cin.ignore(); getline(cin, *contactNo);
}
//Qualifications
void Registeration::setQ()
{
	qualification = new string();
	cout << "Enter Qualifications: "; getline(cin, *qualification);
}
//Registeration Date from the system
void Registeration::setRd()
{
	regDate = new string();
	string temp;
	time_t now = time(0);
	char date_time[26]; ctime_s(date_time, 26, &now);
	for (int i = 0; date_time[i] != '\0'; ++i) {
		if (date_time[i] != '\n') {
			if (i >= 4 && i <= 10) {
				temp += date_time[i];
			}
			else if (i >= 20) {
				temp += date_time[i];
			}
		}
	}
	*regDate = temp;
	cout << "Registeration Date: " << *regDate << endl;
}
//Address
void Registeration::setAd()
{
	int check = 0;
	address.state = new string();
	address.city = new string();
	address.area = new string();
	address.houseNo = new string();
	address.zip = new int();

	cout << "\t{Your Residence}\nEnter State: "; cin >> *address.state;
	cout << "Enter City: "; cin >> *address.city;
	cout << "Enter Area: "; cin >> *address.area;
	cout << "Enter House No: ";cin >> *address.houseNo;
	cout << "Enter Zip/Postal Code: "; cin >> *address.zip; 

}
//Getters
//First Name
string Registeration::getFn()
{
	return *fName;
}
//Last Name
string Registeration::getLn()
{
	return *lName;
}
//Department Name
string Registeration::getDn()
{
	return *department;
}
//Gender
string Registeration::getG()
{
	return *gender;
}
//Contact
string Registeration::getCn()
{
	return *contactNo;
}
//Qualifications
string Registeration::getQ()
{
	return *qualification;
}
//Registeration Date from the system
string Registeration::getRd()
{
	return *regDate;
}
//Address
void Registeration::getAd()
{
	cout << "Address: " << *address.houseNo << " " << *address.area << " "
		<< *address.city << " " << *address.state << ".\n";
}
//Address - State
string Registeration::getAds()
{
	return *address.state;
}
//Address - City
string Registeration::getAdc()
{
	return *address.city;
}
//Address - Area
string Registeration::getAda()
{
	return *address.area;
}
//Address - House #
string Registeration::getAdh()
{
	return *address.houseNo;
}
//Address - ZIP
int Registeration::getAdz()
{
	return *address.zip;
}

//Specific TeacherReg
//Constructor
TeacherReg::TeacherReg()
{
	*this->TregNo = " ";
	*this->username = " ";
	*this->password = " ";
	*this->Course = " ";
	interest = 0;
	CS = 0;
	EE = 0;
	SS = 0;
	SE = 0;
	B = 0;
}
//Destructor
TeacherReg::~TeacherReg()
{
	delete[]TregNo;
	delete[]username;
	delete[]password;

}
//Add zero before the first of roll numbers or reg numbers
string Registeration::AddZero(int tCount) {
	string temp;
	if (tCount < 10) {
		temp = "000" + to_string(tCount);
	}
	else if (tCount < 100) {
		temp = "00" + to_string(tCount);
	}
	else if (tCount < 1000) {
		temp = "0" + to_string(tCount);
	}
	else if (tCount < 10000) {
		temp = to_string(tCount);
	}
	return temp;
}
//Count of Teachers in Each Department
void TeacherReg::Tcount() {
	ifstream in;
	string str;
	in.open("TeachinDept.txt");
	do {
		getline(in, str);
		if (str == "CS") {
			getline(in, str);
			CS = stoi(str);
		}
		else if (str == "EE") {
			getline(in, str);
			EE = stoi(str);
		}
		else if (str == "SS") {
			getline(in, str);
			SS = stoi(str);
		}
		else if (str == "SE") {
			getline(in, str);
			SE = stoi(str);
		}
		else if (str == "B") {
			getline(in, str);
			B = stoi(str);
		}
	} while (!in.eof());
	in.close();
}
//Updating the number of Teachers in each department
void TeacherReg::Cstore() {
	ofstream out;
	string str;
	out.open("TeachInDept.txt");
	out << "CS\n" << CS << "\nEE\n" << EE << "\nSS\n" << SS << "\nSE\n" << SE << "\nB\n" << B;
	out.close();
}
//Setters
//Teacher Registeration Number
void TeacherReg::setTn()
{
	TregNo = new string();
	string dept;
	string Temp;
	dept = getDn();
	do {
		if (dept == "Computer Science") {
			dept = "CS";
			++CS;
			Temp = AddZero(CS);
			break;
		}
		else if (dept == "Electric Engeneering") {
			dept = "EE";
			++EE;
			Temp = AddZero(EE);
			break;
		}
		else if (dept == "Software Engeneering") {
			dept = "SE";
			++SE;
			Temp = AddZero(SE);
			break;
		}
		else if (dept == "Business") {
			dept = "B";
			++B;
			Temp = AddZero(B);
			break;
		}
		else if (dept == "Social Sciences") {
			dept = "SS";
			++SS;
			Temp = AddZero(SS);
			break;
		}
	} while (1);


	*TregNo = dept + "-" + Temp;
	cout << "\tYour Reg No: " << *TregNo << endl;
}
//Edit
void TeacherReg::setTn(string roll)
{
	TregNo = new string();
	*TregNo = roll;
	cout << "\tYour Reg No: " << *TregNo << endl;

}
//Username
void TeacherReg::setUn()
{
	username = new string();
	cout << "Enter Desired Username(no spaces or charchters): ";
	cin.ignore();
	getline(cin, *username);
	ofstream fout;
	fout.open("TeachLogin.txt",ios::app);
	fout << *username << " ";
	fout.close();
}
//Password
void TeacherReg::setPs()
{
	password = new string();
	cout << "Enter a Secure Password: ";
	getline(cin, *password);
	ofstream fout;
	fout.open("TeachLogin.txt",ios::app);
	fout << *password << endl;
	fout.close();
}
//assigning the topic, teacher is going to teach.
void TeacherReg::setInterest()
{
	int check = 0;
	do {
		if (check != 0) cout << "\nINCORRECT INPUT!\n";
		cout << "Topic of Interest: (You want to Teach)\n"
			<< "1- Programming Fundamentals + Lab\n2- Introduction to Computer and Technology Lab\n3- English + Lab"
			<< "\n4- Linear Algebra\n5- Calculus"
			<< "\n6- Applied Physics\n7- Digital Logic Design"
			<< "\n8- Pak. Studies\t/\t9- Islamiyat\nEnte Choice: "; cin >> interest; check++; system("cls");
	} while (!(interest >= 1 && interest <= 9));
	check = 0;
}
//storing the respected courses into respected files
void TeacherReg::TeachCourse() {
	string fName;
	switch (interest) {
	case 1:
		fName = "PF.txt";
		break;
	case 2:
		fName = "ICT.txt";
		break;
	case 3:
		fName = "ENG.txt";
		break;
	case 4:
		fName = "LA.txt";
		break;
	case 5:
		fName = "CAL.txt";
		break;
	case 6:
		fName = "AP.txt";
		break;
	case 7:
		fName = "DLD.txt";
		break;
	case 8:
		fName = "PS.txt";
		break;
	case 9:
		fName = "ISL.txt";
		break;
	}
	string str;
	ifstream iin;
	ofstream oout;
	iin.open(fName);
	oout.open("temp.txt");
	do {
		getline(iin, str);
		if (str == "Students:") {
			oout << *TregNo << endl;
		}
		oout << str << endl;
	} while (!iin.eof());
	oout.close();
	iin.close();
	ifstream sin;
	ofstream sout;
	sout.open(fName);
	sin.open("temp.txt");
	do {
		getline(sin, str);
		sout << str << endl;
	} while (!sin.eof());
	sin.close();
	sout.close();
}
//returning value of topic teacher is going to teach
int TeacherReg::getInterest()
{
	return interest;
}
//Setters
//Teacher Registeration Number
string TeacherReg::getTn()
{
	return *TregNo;
}
//Username
string TeacherReg::getUn()
{
	return *username;
}
//Password
string TeacherReg::getPs()
{
	return *password;
}

//Specific StudentReg
//Constructors
StudentReg::StudentReg()
{
	this->SregNo = new string("");
	this->marks = new int(0);
	this->bloodGroup = new string("");
	this->pass = new string("");
	this->course = new int(0);
	feeStatus = false;
}
//Destructors
StudentReg::~StudentReg()
{
	delete SregNo;
	delete bloodGroup;
	delete marks;
	*course = 0;
	feeStatus = false;
}
//Setters
//Student Roll Numbers
void StudentReg::setSn()
{
	SregNo = new string();
	Registeration obj;
	string batch = "";
	string temp;
	temp = obj.getRd();
	int sCount = 0;

	time_t now = time(0);
	char date_time[26]; ctime_s(date_time, 26, &now);
	for (int i = 0; date_time[i] != '\0'; ++i) {
		if (date_time[i] != '\n') {
			if (i >= 22) {
				batch += date_time[i];
			}
		}
	}

	ifstream read;
	read.open("stdLogin.txt");
	do { getline(read, temp); ++sCount; } while (!read.eof());
	read.close();
	temp = AddZero(sCount);
	cout << "Batch: " << batch;
	*SregNo = batch + "F-" + temp;
	cout << "\tYour Roll No: " << *SregNo << endl;
}
//Edit
void StudentReg::setSn(string roll)
{	
	SregNo = new string();
	*SregNo = roll;
	cout << "\tYour Roll No: " << *SregNo << endl;
}
//Blood Group
void StudentReg::setBg()
{
	bloodGroup = new string();
	cout << "Enter Blood Group: "; cin.ignore(); getline(cin, *bloodGroup);
}
//Fee Status
void StudentReg::setFs()
{
	char temp;
	do {
		cout << "\t{Fee Status}\nP- Paid / N- Not Paid\nEnter Charachter: "; cin >> temp;
	} while (temp != 'p' && temp != 'P' && temp != 'N' && temp != 'n');
	switch (temp) {
	case 'P':
	case'p':
		this->feeStatus = true;
		break;
	case 'N':
	case'n':
		this->feeStatus = false;
		break;
	}
}
//Marks
void StudentReg::setM()
{
	marks = new int();
	string temp;
	do {
		cout << "Enter marks (0-100): ";
		cin >> temp;

		if (stoi(temp) < 0 || stoi(temp) > 100) {
			cout << "Invalid input. Please enter a value between 0 and 100." << endl;
		}
		else {
			*marks = stoi(temp);
			break;
		}
	} while (true);

	
//Password
void StudentReg::setPass() {
	pass = new string;
	cout << "Create Password: "; cin >> *pass;
	system("cls");
}
//Login Username(Roll-Num) and Password
void StudentReg::Login() {
	ofstream write;
	write.open("stdLogin.txt", ios::app);
	write << getSn() << " ";
	write << getPass() << endl;
	write.close();
}
//Register Courses according to Students
void StudentReg::setCourse()
{
	string TempR;
	int temp[6] = { 1, 2, 3, 0, 0, 0 },check=0;
	course = temp;
	cout << "There is a credit hour limit for you. (Therefore, you are limited to picking 6 courses.)\n";
	cout << "\nMandatory Courses:\n\t1- Programming Fundamentals + Lab\n\t2- Introduction to Computer and Technology Lab\n\t3- English + Lab";
	do {
		if (check != 0) cout << "\nINCORRECT INPUT!\n";
		cout << "\nYou May Select One from Following Pairs: \n\t4- Linear Algebra\t\t5- Calculus\n"; 
		cout << "Enter Choice:";
		cin >> temp[3];
		check++;
		system("cls");
	} while (!(temp[3] >= 4 && temp[3] <= 5)); check = 0;

	do {
		if (check != 0) cout << "\nINCORRECT INPUT!\n";
	cout << "\n\t6- Applied Physics\t\t7- Digital Logic Design\nEnter Choice:";
	cin >> temp[4];
	check++;
	system("cls");
	} while (!(temp[4] >= 6 && temp[4] <= 7)); check = 0;

	do {
		if (check != 0) cout << "\nINCORRECT INPUT!\n";
		cout << "\n\t8- Pak. Studies\t\t9- Islamiyat\nEnter Choice: ";
		cin >> temp[5];
		check++;
		system("cls");
	} while (!(temp[5] >= 8 && temp[5] <= 9)); check = 0;

	// Output the values of the temp array
	system("cls");
	cout << "Selected ";
	int tem;
	for (int i = 0; i < 6; i++) {
		tem = temp[i];
		switch (tem) {
			cout << course[i];
		case 1:
			TempR = "\n\tProgramming Fundamentals + Lab\n";
			break;
		case 2:
			TempR += "\tIntroduction to Computer and Technology Lab\n";
			break;
		case 3:
			TempR += "\tEnglish + Lab\n";
			break;
		case 4:
			TempR += "\tLinear Algebra\n";
			break;
		case 5:
			TempR += "\tCalculus\n";
			break;
		case 6:
			TempR += "\tApplied Physics\n";
			break;
		case 7:
			TempR += "\tDigital Logic Design\n";
			break;
		case 8:
			TempR += "\tPak. Studies\n";
			break;
		case 9:
			TempR += "\tIslamiyat\n";
			break;
		}
	}
	cout << "Courses: " << TempR << endl;;
	cout << endl;
}
//registering specific stuedents into respected courses files
void StudentReg::StudyCourse() {
	string fName;
	for(int i=0;i<6;++i){
		arr[i] = course[i];
		switch (course[i]) {
		case 1:
			fName = "PF.txt";
			break;
		case 2:
			fName = "ICT.txt";
			break;
		case 3:
			fName = "ENG.txt";
			break;
		case 4:
			fName = "LA.txt";
			break;
		case 5:
			fName = "CAL.txt";
			break;
		case 6:
			fName = "AP.txt";
			break;
		case 7:
			fName = "DLD.txt";
			break;
		case 8:
			fName = "PS.txt";
			break;
		case 9:
			fName = "ISL.txt";
			break;
		}
		string str;
		ifstream fin;
		ofstream fout;
		fout.open(fName,ios::app);
		fout << *SregNo << endl;
		fin.close();
		fout.close();
	}
}

//Getters
//Student Roll Numbers
string StudentReg::getSn()
{
	return *SregNo;
}
//Blood Group
string StudentReg::getBg()
{
	return *bloodGroup;
}
//Fee Status
bool StudentReg::getFs()
{
	return feeStatus;
}
//Marks
int StudentReg::getM()
{
	return *marks;
}
//Password
string StudentReg::getPass() {
	return *pass;
}
//Courses
string StudentReg::getCourse()
{
	int chkI;
	
	string result;
	for (int i = 0; i < 6; i++) {
		chkI = arr[i];
		switch (chkI) {
		case 1:
			result +=" 1";
			break;
		case 2:
			result += " 2";
			break;
		case 3:
			result += " 3";
			break;
		case 4:
			result += " 4";
			break;
		case 5:
			result += " 5";
			break;
		case 6:
			result += " 6";
			break;
		case 7:
			result += " 7";
			break;
		case 8:
			result += " 8";
			break;
		case 9:
			result += " 9";
			break;
		}
	}
	return result;
}

//Admin Module
//Constructor
AdminControls::AdminControls()
{
	noOfStudents = 1;
	noOfTeachers = 1;
}
//Destructor
AdminControls::~AdminControls()
{
	delete[]stud;
	delete[]teach;
	stud = NULL;
	teach = NULL;

}
//Register a new Student
void AdminControls::newStudent()
{
	//increaseS(stud,noOfStudents);
	stud[noOfStudents].setFn();
	stud[noOfStudents].setLn();
	stud[noOfStudents].setDn();
	stud[noOfStudents].setG();
	stud[noOfStudents].setCn();
	stud[noOfStudents].setQ();
	stud[noOfStudents].setRd();
	stud[noOfStudents].setAd();
	stud[noOfStudents].setSn();
	stud[noOfStudents].setBg();
	stud[noOfStudents].setFs();
	stud[noOfStudents].setM();
	stud[noOfStudents].setPass();
	stud[noOfStudents].Login();
	stud[noOfStudents].setCourse();
	stud[noOfStudents].StudyCourse();
}
//Update after editing the Registered Student
void AdminControls::newStudent(string roll)
{
	//increaseS(stud,noOfStudents);
	stud[noOfStudents].setFn();
	stud[noOfStudents].setLn();
	stud[noOfStudents].setDn();
	stud[noOfStudents].setG();
	stud[noOfStudents].setCn();
	stud[noOfStudents].setQ();
	stud[noOfStudents].setRd();
	stud[noOfStudents].setAd();
	stud[noOfStudents].setSn(roll);
	stud[noOfStudents].setBg();
	stud[noOfStudents].setFs();
	stud[noOfStudents].setM();
	stud[noOfStudents].setPass();
	stud[noOfStudents].Login();
}
//Register a new Teacher
void AdminControls::newTeacher()
{
	//increaseT(teach,noOfTeachers);
	teach[noOfTeachers].setFn();
	teach[noOfTeachers].setLn();
	teach[noOfTeachers].setDn();
	teach[noOfTeachers].setG();
	teach[noOfTeachers].setCn();
	teach[noOfTeachers].setQ();
	teach[noOfTeachers].setRd();
	teach[noOfTeachers].setAd();
	teach[noOfTeachers].Tcount();
	teach[noOfTeachers].setTn();
	teach[noOfTeachers].Cstore();
	teach[noOfTeachers].setUn();
	teach[noOfTeachers].setPs();
	teach[noOfTeachers].setInterest();
	teach[noOfTeachers].TeachCourse();

}
//Update after editing the Registered Student
void AdminControls::newTeacher(string roll)
{
	teach[noOfTeachers].setFn();
	teach[noOfTeachers].setLn();
	teach[noOfTeachers].setDn();
	teach[noOfTeachers].setG();
	teach[noOfTeachers].setCn();
	teach[noOfTeachers].setQ();
	teach[noOfTeachers].setRd();
	teach[noOfTeachers].setAd();
	teach[noOfTeachers].setTn(roll);
	teach[noOfTeachers].setUn();
	teach[noOfTeachers].setPs();

}
//File Handling of a Student
void AdminControls::fileHandlingStd()
{
	ofstream fout("student.txt", ios::app);
	if (!fout)
	{
		cout << "ERROR: MISSING FILE";
		return;
	}
	else {
		StudentReg* obj = &stud[noOfStudents];
		fout << "\nName: " << obj->getFn() << " " << obj->getLn();
		fout << "\nReg No: " << obj->getSn();
		fout << "\nDepartment: " << obj->getDn();
		fout << "\nGender: " << obj->getG();
		fout << "\nContact: " << obj->getCn();
		fout << "\nQualification: " << obj->getQ();
		fout << "\nRegisteration Date: " << obj->getRd();
		fout << "\nAddress: " << obj->getAdh() << " " << obj->getAda() << " " << obj->getAdc()
			<< " " << obj->getAds() << " " << obj->getAdz() << ". ";
		fout << "\nBlood Group: " << obj->getBg();
		fout << "\nMarks: " << obj->getM();
		fout << "\nFee Status: ";
		if (obj->getFs())
			fout << "Paid\n";
		else
			fout << "Not Paid\n";
		fout << "Courses: " << obj->getCourse() << endl;
	}
	fout.close();
}
//File Handling of a Teacher
void AdminControls::fileHandlingTch()
{
	ofstream fout("teacher.txt", ios::app);
	if (!fout)
	{
		cout << "ERROR: MISSING FILE";
		return;
	}
	else {
		TeacherReg* obj = &teach[noOfTeachers];
		fout << "Name: " << obj->getFn() << " " << obj->getLn();
		fout << "\nReg No: " << obj->getTn();
		fout << "\nDepartment: " << obj->getDn();
		fout << "\nGender: " << obj->getG();
		fout << "\nContact: " << obj->getCn();
		fout << "\nQualification: " << obj->getQ();
		fout << "\nRegisteration Date: " << obj->getRd();
		fout << "\nAddress: " << obj->getAdh() << " " << obj->getAda() << " " << obj->getAdc()
			<< " " << obj->getAds() << " " << obj->getAdz() << ".";
		fout << "\nUsername: " << obj->getUn();
		fout << "\nPassword: " << obj->getPs();
		fout << "\nCourse: " << obj->getInterest() << endl << endl;

	}
	fout.close();
}
//Registerations
void AdminControls::Register()
{
	char temp;
	do {
		cout << "\t{Register}\nS- Student / T- Teacher\nEnter Charachter: "; cin >> temp;
	} while (temp != 'S' && temp != 's' && temp != 'T' && temp != 't');
	switch (temp) {
	case 'S':
	case 's':
		newStudent(); cin.ignore();
		fileHandlingStd();
		break;
	case 'T':
	case 't':
		newTeacher();
		fileHandlingTch();
		break;
	}
}
void AdminControls::edit()
{
	ifstream fin;
	string roll, temp;
	int lim, lineCount = 0;
	bool Schk = false, Tchk = false; // Initialize Schk and Tchk to false
	do {
		cout << "\t\t1- Student\n\t\t2- Teacher\nEnter Number: ";
		cin >> lim;
	} while (lim < 1 || lim > 2);

	if (lim == 1) {
		fin.open("student.txt");
		ViewS();
		cout << "Enter the Student's Roll No to update Information: ";
		cin >> roll;
		do {
			getline(fin, temp);
			++lineCount;
			if (temp.substr(0, 3) == "Reg") {
				if (temp.substr(8, 8) == roll) {
					Schk = true;
					break;
				}
			}
		} while (!fin.eof());
		fin.close();
	}
	else {
		fin.open("teacher.txt");
		cout << "Enter Reg No: ";
		cin >> roll;
		do {
			getline(fin, temp);
			++lineCount;
			if (temp.substr(0, 3) == "Reg") {
				if (temp.substr(8, 8) == roll) {
					Tchk = true;
					break;
				}
			}
		} while (!fin.eof());
		fin.close();
	}
	if (!Schk && !Tchk) {
		cout << "Error! Not in Record!\n";
	}
	else if (Schk) {
		int sCount = 0;
		bool check = false;
		string tempstr;
		ofstream fout;
		fout.open("temp.txt");
		fin.open("student.txt");
		do {
			if (check) {
				getline(fin, tempstr);
			}
			else {
				getline(fin, tempstr);
				fout << tempstr << endl;
			}
			if (tempstr.substr(0, 3) == "Reg" && tempstr.substr(8, 8) == roll) {
				check = true;
			}
			if (check && sCount == 9) { // Adjusted the line count here
				check = false;
			}
			++sCount;
		} while (!fin.eof());
		fin.close();
		fout.close();
		fout.open("student.txt");
		fin.open("temp.txt");
		do {
			getline(fin, tempstr);
			fout << tempstr << endl;
		} while (!fin.eof());
		fin.close();
		fout.close();
		newStudent(roll);
		fileHandlingStd();
	}
	else if (Tchk) {
		int tCount = 0;
		bool checkT = false;
		string tempstr;
		ofstream fout;
		fout.open("temp.txt");
		fin.open("teacher.txt");
		do {
			if (checkT) {
				getline(fin, tempstr);
			}
			else {
				getline(fin, tempstr);
				fout << tempstr << endl;
			}
			if (tempstr.substr(0, 3) == "Reg" && tempstr.substr(8, 8) == roll) {
				checkT = true;
			}
			if (checkT && tCount == 8) { // Adjusted the line count here
				checkT = false;
			}
			++tCount;
		} while (!fin.eof());
		fin.close();
		fout.close();
		fout.open("teacher.txt");
		fin.open("temp.txt");
		do {
			getline(fin, tempstr);
			fout << tempstr << endl;
		} while (!fin.eof());
		fin.close();
		fout.close();
		newTeacher(roll);
		fileHandlingTch();
	}
}



//View All Students
void AdminControls::ViewS()
{
	ifstream fin;
	string str;
	fin.open("student.txt");
	do {
		getline(fin, str);
		cout << str << endl;
	} while (!fin.eof());
	fin.close();
}
//View All Teachers
void AdminControls::ViewT()
{
	int count = 0;
	ifstream fin;
	string str;
	fin.open("teacher.txt");
	do {
		getline(fin, str);
		if (str == "")
			continue;
		++count;
		if(count==1|| count == 4 || count == 5 || count == 6 || count == 9)
		cout << str << endl;
		if(count==11) {
			count = 0;
			cout << endl;
		}
	} while (!fin.eof());
	fin.close();
}
void AdminControls::assignStd_Tch()
{
	string fName,sName,str;
	for (int i = 1; i <= 9; ++i) {
		switch (i) {
		case 1:
			fName = "PF.txt";
			sName = "PF_tch.txt";
			break;
		case 2:
			fName = "ICT.txt";
			sName = "ICT_tch.txt";
			break;
		case 3:
			fName = "ENG.txt";
			sName = "ENG_tch.txt";

			break;
		case 4:
			fName = "LA.txt";
			sName = "LA_tch.txt";

			break;
		case 5:
			fName = "CAL.txt";
			sName = "CAL_tch.txt";
			break;
		case 6:
			fName = "AP.txt";
			sName = "AP_tch.txt";
			break;
		case 7:
			fName = "DLD.txt";
			sName = "DLD_tch.txt";
			break;
		case 8:
			fName = "PS.txt";
			sName = "PS_tch.txt";
			break;
		case 9:
			fName = "ISL.txt";
			sName = "ISL_tch.txt";
			break;
		}
		int teachCount = 0, studCount = 0;
		ifstream fin;
		ofstream fout;
		fin.open(fName);
		while (str != "Students:") {
			getline(fin, str);
			if (str != "Teachers:")
				++teachCount;
		}
		--teachCount;
		while (!fin.eof()) {
			getline(fin, str);
			if (str != "")
				++studCount;
		}
		fin.close();

		int lim, tCount = 0, sCount = 0;
		if (studCount == 0 || teachCount == 0)
			continue;
		lim=studCount / teachCount;
		fout.open(sName);
		for (int k = 0; k < teachCount; ++k) {
			fin.open(fName);
			getline(fin, str);
			for(int x=0;x<=tCount;++x)
				getline(fin, str);
			++tCount;
			fout << "Reg No: " << str << endl;
			do {
				getline(fin, str);
			} while (str != "Students:");
			if (sCount > 0) {
				for(int s=0;s<sCount;++s)
					getline(fin, str);
			}
			if (k == teachCount - 1) {
				do{
					getline(fin, str);
					fout << str << endl;
				} while (!fin.eof());
			}
			else {
				for (int j = 0; j < lim; ++j) {
					getline(fin, str);
					fout << str << endl;
				}
				sCount += lim;
			}
			fin.close();
		}

	}
	cout << " done\n";

}

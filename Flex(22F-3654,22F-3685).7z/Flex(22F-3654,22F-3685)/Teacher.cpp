#include "Teacher.h"

void Teacher::Attendance(string str, string course)
{
	//seperation reg no in a char array
	ofstream fout;
	ifstream fin;
	char regNo[8] = { " " };
	for (int i = 0, j = 8; j < str.length(); ++i, ++j) {
		regNo[i] = str[j];
	}
	string fName, sName;
	fName = regNo;
	fName += ".txt";
	string tempi;
	tempi = course[8];
	switch (stoi(tempi)) {
	case 1:
		sName = "PF_tch.txt";
		break;
	case 2:
		sName = "ICT_tch.txt";
		break;
	case 3:
		sName = "ENG_tch.txt";

		break;
	case 4:
		sName = "LA_tch.txt";

		break;
	case 5:
		sName = "CAL_tch.txt";
		break;
	case 6:
		sName = "AP_tch.txt";
		break;
	case 7:
		sName = "DLD_tch.txt";
		break;
	case 8:
		sName = "PS_tch.txt";
		break;
	case 9:
		sName = "ISL_tch.txt";
		break;
	}

	fin.open(sName);
	fout.open(fName,ios::app);
	string temp;
	bool now = false;
	cout << "0 - Absent / 1 - Present :" << endl;

	//date from the system for attendance
	string Date, tempT;
	time_t Tnow = time(0);
	char date_time[26]; ctime_s(date_time, 26, &Tnow);
	for (int i = 0; date_time[i] != '\0'; ++i) {
		if (date_time[i] != '\n') {
			if (i >= 4 && i <= 10) {
				tempT += date_time[i];
			}
			else if (i >= 20) {
				tempT += date_time[i];
			}
		}
	}
	Date = tempT;
	cout << "Date: " << Date << endl;
	fout << "Date: " << Date << endl;
	int att;
	do {
		getline(fin, temp);
		if (now) {
			if (temp == "")
				continue;
			do {
				cout << temp << "\t"; cin >> att;
			} while (att != 1 && att != 0);
			if (att == 1) {
				fout << temp << "\tP" << endl;
			}
			else {
				fout << temp << "\tA" << endl;
			}
		}
		if (temp == str) {
			now = true;
		}
	} while (!fin.eof());
	fout << endl;
	fin.close();
	fout.close();
}

void Teacher::AssignMarks(string str, string course)
{
	ofstream fout;
	ifstream fin;
	char regNo[8] = { " " };
	for (int i = 0, j = 8; j < str.length(); ++i, ++j) {
		regNo[i] = str[j];
	}
	string fName, sName;
	fName = regNo;
	fName += "_Marks";
	fName += ".txt";
	string tempi;
	tempi = course[8];
	switch (stoi(tempi)) {
	case 1:
		sName = "PF_tch.txt";
		break;
	case 2:
		sName = "ICT_tch.txt";
		break;
	case 3:
		sName = "ENG_tch.txt";

		break;
	case 4:
		sName = "LA_tch.txt";

		break;
	case 5:
		sName = "CAL_tch.txt";
		break;
	case 6:
		sName = "AP_tch.txt";
		break;
	case 7:
		sName = "DLD_tch.txt";
		break;
	case 8:
		sName = "PS_tch.txt";
		break;
	case 9:
		sName = "ISL_tch.txt";
		break;
	}

	fin.open(sName);
	fout.open(fName, ios::app);
	string temp,evaluation;
	bool now = false;
	int marksLim;
	cout << "Enter Evaluation Name: "; getline(cin, evaluation);
	cout << "Enter Total marks for '" << evaluation << "': "; cin >> marksLim;

	
	int marks;
	do {
		getline(fin, temp);
		if (now) {
			if (temp == "")
				continue;
			do {
				cout << temp << "\t"; cin >> marks;
			} while (marks <0 || marks > marksLim);
			fout << temp << "\t"<<marks << endl;
		}
		if (temp == str) {
			now = true;
		}
	} while (!fin.eof());
	fout << endl;
	fin.close();
	fout.close();
}

void Teacher::AssignGrades(string str, string course)
{
	ofstream fout;
	ifstream fin;
	char regNo[8] = { " " };
	for (int i = 0, j = 8; j < str.length(); ++i, ++j) {
		regNo[i] = str[j];
	}
	string fName, sName;
	fName = regNo;
	fName += "_Grades";
	fName += ".txt";
	string tempi;
	tempi = course[8];
	switch (stoi(tempi)) {
	case 1:
		sName = "PF_tch.txt";
		break;
	case 2:
		sName = "ICT_tch.txt";
		break;
	case 3:
		sName = "ENG_tch.txt";

		break;
	case 4:
		sName = "LA_tch.txt";

		break;
	case 5:
		sName = "CAL_tch.txt";
		break;
	case 6:
		sName = "AP_tch.txt";
		break;
	case 7:
		sName = "DLD_tch.txt";
		break;
	case 8:
		sName = "PS_tch.txt";
		break;
	case 9:
		sName = "ISL_tch.txt";
		break;
	}

	fin.open(sName);
	fout.open(fName, ios::app);
	string temp, grade;
	bool now = false;
	system("cls");
	cout << "Use UPPERCASE letters only!\n";
	cout << "Enter Final Grades: \n";
	do {
		getline(fin, temp);
		if (now) {
			if (temp == "")
				continue;
			do {
				cout << temp << "\t"; cin >> grade;
			} while (grade !="A+" && grade !="A" && grade !="A-"&&
				grade != "B+" && grade != "B" && grade != "B-"&&
				grade != "C+" && grade != "C" && grade != "C-"&&
				grade != "D+" && grade != "D" && grade != "D-" && grade != "F");
			fout << temp << "\t" << grade << endl;
		}
		if (temp == str) {
			now = true;
		}
	} while (!fin.eof());
	fout << endl;
	fin.close();
	fout.close();
}

void Teacher::TimeTable(string str, string course)
{
	string Date, tempT;
	time_t Tnow = time(0);
	char date_time[26]; ctime_s(date_time, 26, &Tnow);
	for (int i = 0; date_time[i] != '\0'; ++i) {
		if (date_time[i] != '\n') {
			if (i >= 4 && i <= 10) {
				tempT += date_time[i];
			}
			else if (i >= 20) {
				tempT += date_time[i];
			}
		}
	}
	Date = tempT;
	string tempi, sName;
	tempi = course[8];
	switch (stoi(tempi)) {
	case 1:
		sName = "PF";
		break;
	case 2:
		sName = "ICT";
		break;
	case 3:
		sName = "ENG";

		break;
	case 4:
		sName = "LA";

		break;
	case 5:
		sName = "CAL";
		break;
	case 6:
		sName = "AP";
		break;
	case 7:
		sName = "DLD";
		break;
	case 8:
		sName = "PS";
		break;
	case 9:
		sName = "ISL";
		break;
	}
	srand(time(0));
	int randomNum = rand() % 20 + 1;
	cout << "Upcoming Lecture: \n";
	cout << "\t\t\t\t\t\t- - - -- - - - - \n";
	cout << "\t\t\t\t\t\t|" << Date  << "\t|" << endl;
	cout << "\t\t\t\t\t\t|" << "\t" << sName << "\t|" << endl;
	cout << "\t\t\t\t\t\t|"  << "\tRoom "<<randomNum << "\t|" << endl;
	cout << "\t\t\t\t\t\t- - - --  - - - -\n";
	cout << "If you want to Change Room select TimeTable again, It will be shared with Students!\n";
}

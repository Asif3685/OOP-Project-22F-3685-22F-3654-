#include"AdminControls.h"
#include "Teacher.h"
#include"Student.h"
#include<windows.h>
#include <stdlib.h>

HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);

void load() {
	system("cls");
	cout << "\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tLoading.";
	Sleep(1000);
	system("cls");
	cout << "\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tLoading..";
	Sleep(1);
	system("cls");
	cout << "\n\n\n\n\n\n\n\n\t\t\t\t\t\t\tLoading...";
	Sleep(1000);
	system("cls");
}
//Student's Module
void StudentMod(string rollNo){
	cout << "\t\t\t\t\t\t\tWelcome Students\n\n\n\n";
	
	//Extraction of users reg no and course
	ifstream fin;
	string str, course, fee, name;
	bool pass = false, tru = false;
	int count = 0;
	fin.open("student.txt");
	do {
		getline(fin, str);
		if (str[0] == 'R' && str[1] == 'e' && str[2] == 'g' && str[3] == ' ' &&
			str[4] == 'N' && str[5] == 'o' && str[6] == ':' && str[7] == ' ') {
			pass = true;
		}

		if (pass == true) {
			for (int i = 0; i < rollNo.length(); ++i) {
				if (str[i + 8] == rollNo[i]) {
					pass = true;
				}
				else {
					pass = false;
					break;
				}
				if (i == (rollNo.length() - 1)) {
					if (pass == true) {
						tru = true;
					}
				}
			}
		}
		if (tru == true) {
			break;
		}
		++count;

	} while (!fin.eof());
	fin.close();
	fin.open("student.txt");
	for (int i = 0; i < count + 11; ++i) {
		getline(fin, course);
	}
	fin.close();
	fin.open("student.txt");
	for (int i = 0; i < count + 10; ++i) {
		getline(fin, fee);
	}
	fin.close();
	fin.open("student.txt");
	for (int i = 0; i < count; ++i) {
		getline(fin, name);
	}
	fin.close();

	do {
		int check = 0;
		Student obj;
		int choice;
		do {
			SetConsoleTextAttribute(h, 12);
			if (check != 0) cout << "\nINCORRECT INPUT!\n";
			SetConsoleTextAttribute(h, 6);
			cout << "\t\t1- View Attendance\n";
			cout << "\t\t2- View Marks\n";
			cout << "\t\t3- View Grades\n";
			cout << "\t\t4- View Courses\n";
			cout << "\t\t5- View Fee Status\n";
			cout << "\t\t6- Exit\n";
			cout << "\n\tEnter Number: "; cin >> choice; ++check;
		} while (!(choice >= 1 && choice <= 6)); check = 0;
		system("cls");
		switch (choice) {
		case 1:
			obj.ViewAttendance(rollNo, course);
			break;
		case 2:
			obj.ViewMarks(rollNo, course);
			break;
		case 3:
			obj.ViewGrades(rollNo, course);
			break;
		case 4:
			obj.ViewCourses(rollNo, course);
			break;
		case 5:
			obj.ViewFeeStatus(rollNo, fee, name);
			break;
		case 6:
			exit(1);
			break;
		}
		system("cls");
	} while (1);

}
//Teacher's Module
void TeacherMod(string username) {
	cout << "\t\t\t\t\t\t\tWelcome Teachers!\n\n\n\n" << endl;

	//Extraction of users reg no and course
	ifstream fin;
	string str, course;
	bool pass = false, tru = false;
	int count = 0;
	fin.open("teacher.txt");
	do {
		getline(fin, str);
		if (str[0] == 'U' && str[1] == 's' && str[2] == 'e' && str[3] == 'r'
			&& str[4] == 'n' && str[5] == 'a' && str[6] == 'm' && str[7] == 'e'
			&& str[8] == ':' && str[9] == ' ') {
			pass = true;

		}

		if (pass == true) {
			for (int i = 0; i < username.length(); ++i) {
				if (str[i + 10] == username[i]) {
					pass = true;
				}
				else {
					pass = false;
					break;
				}
				if (i == (username.length() - 1)) {
					if (pass == true) {
						tru = true;
					}
				}
			}
		}
		if (tru == true) {
			break;
		}
		++count;

	} while (!fin.eof());
	fin.close();
	fin.open("teacher.txt");
	for (int i = 0; i < count - 6; ++i) {
		getline(fin, str);
	}
	fin.close();
	fin.open("teacher.txt");
	for (int i = 0; i < count + 3; ++i) {
		getline(fin, course);
	}
	fin.close();
	do {
		int check = 0;
		Teacher obj;
		int choice;
		do {
			SetConsoleTextAttribute(h, 12);
			if (check != 0) cout << "\nINCORRECT INPUT!\n";
			SetConsoleTextAttribute(h, 6);
			cout << "\t\t1- Mark Today's Attendance\n";
			cout << "\t\t2- Upload Marks\n";
			cout << "\t\t3- Assign Grades\n";
			cout << "\t\t4- View Your Timetable\n";
			cout << "\t\t5- Exit\n";
			cout << "\n\tEnter Number: "; cin >> choice; ++check;
		} while (!(choice >= 1 && choice <= 5)); check = 0;
		system("cls");

		switch (choice) {
		case 1:
			obj.Attendance(str, course);
			break;
		case 2:
			obj.AssignMarks(str, course);
			break;
		case 3:
			obj.AssignGrades(str, course);
			break;
		case 4:
			obj.TimeTable(str, course);
			break;
		case 5:
			exit(1);
			break;
		}
		system("cls");
	} while (1);

}
//Admin's Module
void Admin() {
	AdminControls admin;
	int tem, check=0;
	do {
		cout << "\t\t\t\t\t\t\t\t{Welcome Admin}\n";
		do {
			SetConsoleTextAttribute(h, 12);
			if (check != 0) { cout <<endl<< "INCORRECT INPUT" << endl; }
			SetConsoleTextAttribute(h, 6);
			cout << "\t\t1- Register\n\t\t2- Edit\n\t\t3- View All Students"
				<<"\n\t\t4 - View All Teachers\n\t\t5 - Exit\n\t Enter Choice : "; cin >> tem;
			check++;
		} while (tem < 1 || tem > 5);
		check = 0;
		system("cls");
		if (tem == 1) {
			admin.Register();
			admin.assignStd_Tch();
		}
		else if (tem == 2) {
			admin.edit();
		}
		else if(tem==3){
			admin.ViewS();
		}
		else if (tem==4) {
			admin.ViewT();
		}
		else if (tem == 5) {
			break;
		}
		system("pause");
		system("cls");
	} while (1);
}
//Sign in for everyone on a single page
void SignIn() {
	ifstream fin;
	string username, password;
	string user, pass, temp;
	bool tru = false, ok = false;
	bool student = false, teacher = false, admin = false;
	cout << "\t\t\t\t\t\t\t{Login Page}\n\n\n\n\n";
	do {
		cout << "\t\tEnter Username: "; cin >> username;
		cout << "\t\tEnter Password: "; cin >> password;
		load();
		if (username == "admin") {
			if (password == "admin") {
				admin = true;
			}
			else {
				cout << "Wrong Pass\n";
				SignIn();
			}
		}
		fin.open("TeachLogin.txt");
		do {
			if (admin) {
				break;
			}
			getline(fin, temp);
			ok = false;
			for (int i = 0; i < temp.length(); ++i) {
				if (temp[i] == ' ') {
					ok = true;
					continue;
				}
				if (!ok) {
					user += temp[i];
				}
				else {
					pass += temp[i];
				}
			}
			if (username == user) {
				if (password == pass) {
					tru = true;
					teacher = true;
					break;
				}
			}
			else {
				user = "";
				pass = "";
			}
		} while (!fin.eof());
		fin.close();
		fin.open("stdLogin.txt");
		do {
			if (admin) {
				break;
			}
			if (teacher) {
				break;
			}
			getline(fin, temp);
			ok = false;
			for (int i = 0; i < temp.length(); ++i) {
				if (temp[i] == ' ') {
					ok = true;
					continue;
				}
				if (!ok) {
					user += temp[i];
				}
				else {
					pass += temp[i];
				}
			}
			if (username == user) {
				if (password == pass) {
					tru = true;
					student = true;
					break;
				}
			}
			else {
				user = "";
				pass = "";
			}
		} while (!fin.eof());
		fin.close();
		system("cls");
		if (admin) {
			tru = true;
			Admin();
		}
		else if (teacher) {
			tru = true;
			TeacherMod(username);
		}
		else if (student) {
			tru = true;
			StudentMod(username);
		}
		else {
			tru = false;
			cout << "ERROR! Not in Records\n";
		}
	} while (!tru);
}
// designing home page
void Home() {
	SetConsoleTextAttribute(h, 6);
	cout << endl;
	cout << "- - - - -- - - - - -- - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - - - - -- - -- - - - - - - - - - - -- -\n";
	cout << "|\t\t\t|||||||||||||||   |||              |||||||||||||||     ||||    //// \t\t\t\t|\n";
	cout << "|\t\t\t||||              |||              ||||                 ||||  ////  \t\t\t\t|\n";
	cout << "|\t\t\t||||              |||              ||||                  ||||////   \t\t\t\t|\n";
	cout << "|\t\t\t||||||||          |||              ||||||||||             ||||//    \t\t\t\t|\n";
	cout << "|\t\t\t||||||||          |||              ||||||||||              ||||     \t\t\t\t|\n";
	cout << "|\t\t\t||||              |||              ||||                   ///|||    \t\t\t\t|\n";
	cout << "|\t\t\t||||              |||              ||||                  //// ||||  \t\t\t\t|\n";
	cout << "|\t\t\t||||              |||||||||||||||  |||||||||||||||      ////   |||| \t\t\t\t|\n\n";
	cout << "- - - - -- - - - - -- - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - - - - -- - - - - - - - - - - -- - - -\n";
	system("pause");
	system("cls");
	SignIn();
}

int main(unsigned) {
	Home();
	return 0;
}

#include "Student.h"

void Student::ViewAttendance(string rollNo, string courses)
{
	ifstream fin;
	string sName;
	string x;
	char regNo[8] = { " " };

	for (int i = 9; i < courses.length(); ++i) {
		if (courses[i] == ' ')
			continue;
		x = courses[i];
		switch (stoi(x)) {
		case 1:
			sName = "PF_tch.txt";
			break;
		case 2:
			sName = "ICT_tch.txt";
			break;
		case 3:
			sName = "ENG_tch.txt";
			break;
		case 4:
			sName = "LA_tch.txt";
			break;
		case 5:
			sName = "CAL_tch.txt";
			break;
		case 6:
			sName = "AP_tch.txt";
			break;
		case 7:
			sName = "DLD_tch.txt";
			break;
		case 8:
			sName = "PS_tch.txt";
			break;
		case 9:
			sName = "ISL_tch.txt";
			break;
		}

		fin.open(sName);
		string str, temp;
		do {
			getline(fin, str);
			if (str[0] == 'R' && str[1] == 'e' && str[2] == 'g') {
				temp = str;
			}
			//cout << "tmp:" << temp << "\n";
			//cout <<"str:"<< str << "\n";
			if (str == rollNo) {
				break;
			}
		} while (!fin.eof());
		for (int i = 0, j = 8; j < temp.length(); ++i, ++j) {
			regNo[i] = temp[j];
		}
		string fName;
		fName += regNo; 
		fName += ".txt";
		ifstream in;
		in.open(fName);
		if (!in) {
			cout << "No classes held yet!\n";
			continue;
		}
		string tmp;
		bool tru = false;
		do {
			getline(in, tmp);
			if (tmp[0] == 'D' && tmp[1] == 'a') {
				cout << tmp << endl;
			}

			if (tmp[0]==rollNo[0]&& tmp[1] == rollNo[1]&& tmp[2] == rollNo[2] && tmp[3] == rollNo[3] && 
				tmp[4] == rollNo[4] && tmp[5] == rollNo[5] && tmp[6] == rollNo[6] && tmp[7] == rollNo[7]) {
				cout << tmp << endl;
			}
		} while (!in.eof());
	}
}

void Student::ViewMarks(string rollNo, string courses)
{
		ifstream fin;
		string sName;
		string x;
		char regNo[8] = { " " };

		for (int i = 9; i < courses.length(); ++i) {
			if (courses[i] == ' ')
				continue;
			x = courses[i];
			switch (stoi(x)) {
			case 1:
				sName = "PF_tch.txt";
				break;
			case 2:
				sName = "ICT_tch.txt";
				break;
			case 3:
				sName = "ENG_tch.txt";
				break;
			case 4:
				sName = "LA_tch.txt";
				break;
			case 5:
				sName = "CAL_tch.txt";
				break;
			case 6:
				sName = "AP_tch.txt";
				break;
			case 7:
				sName = "DLD_tch.txt";
				break;
			case 8:
				sName = "PS_tch.txt";
				break;
			case 9:
				sName = "ISL_tch.txt";
				break;
			}

			fin.open(sName);
			string str, temp;
			do {
				getline(fin, str);
				if (str[0] == 'R' && str[1] == 'e' && str[2] == 'g') {
					temp = str;
				}
				//cout << "tmp:" << temp << "\n";
				//cout <<"str:"<< str << "\n";
				if (str == rollNo) {
					break;
				}
			} while (!fin.eof());
			for (int i = 0, j = 8; j < temp.length(); ++i, ++j) {
				regNo[i] = temp[j];
			}
			string fName;
			fName += regNo;
			fName += "_Marks";
			fName += ".txt";
			ifstream in;
			in.open(fName);
			if (!in) {
				cout << "No classes held yet!\n";
				continue;
			}
			string tmp;
			bool tru = false;
			do {
				getline(in, tmp);
				if (tmp[0] == 'D' && tmp[1] == 'a') {
					cout << tmp << endl;
				}

				if (tmp[0] == rollNo[0] && tmp[1] == rollNo[1] && tmp[2] == rollNo[2] && tmp[3] == rollNo[3] &&
					tmp[4] == rollNo[4] && tmp[5] == rollNo[5] && tmp[6] == rollNo[6] && tmp[7] == rollNo[7]) {
					cout << tmp << endl;
				}
			} while (!in.eof());
		}

}

void Student::ViewGrades(string rollNo, string courses)
{
	ifstream fin;
	string sName;
	string x;
	char regNo[8] = { " " };

	for (int i = 9; i < courses.length(); ++i) {
		if (courses[i] == ' ')
			continue;
		x = courses[i];
		switch (stoi(x)) {
		case 1:
			sName = "PF_tch.txt";
			break;
		case 2:
			sName = "ICT_tch.txt";
			break;
		case 3:
			sName = "ENG_tch.txt";
			break;
		case 4:
			sName = "LA_tch.txt";
			break;
		case 5:
			sName = "CAL_tch.txt";
			break;
		case 6:
			sName = "AP_tch.txt";
			break;
		case 7:
			sName = "DLD_tch.txt";
			break;
		case 8:
			sName = "PS_tch.txt";
			break;
		case 9:
			sName = "ISL_tch.txt";
			break;
		}

		fin.open(sName);
		string str, temp;
		do {
			getline(fin, str);
			if (str[0] == 'R' && str[1] == 'e' && str[2] == 'g') {
				temp = str;
			}
			//cout << "tmp:" << temp << "\n";
			//cout <<"str:"<< str << "\n";
			if (str == rollNo) {
				break;
			}
		} while (!fin.eof());
		for (int i = 0, j = 8; j < temp.length(); ++i, ++j) {
			regNo[i] = temp[j];
		}
		string fName;
		fName += regNo;
		fName += "_Grades";
		fName += ".txt";
		ifstream in;
		in.open(fName);
		if (!in) {
			cout << "No classes held yet!\n";
			continue;
		}
		string tmp;
		bool tru = false;
		do {
			getline(in, tmp);
			if (tmp[0] == 'D' && tmp[1] == 'a') {
				cout << tmp << endl;
			}

			if (tmp[0] == rollNo[0] && tmp[1] == rollNo[1] && tmp[2] == rollNo[2] && tmp[3] == rollNo[3] &&
				tmp[4] == rollNo[4] && tmp[5] == rollNo[5] && tmp[6] == rollNo[6] && tmp[7] == rollNo[7]) {
				cout << tmp << endl;
			}
		} while (!in.eof());
	}

}

void Student::ViewCourses(string rollNo, string courses)
{
	string x;
	string sName;
	int count = 0;
	for (int i = 9; i < courses.length(); ++i) {
		if (courses[i] == ' ')
			continue;
		x = courses[i];
		switch (stoi(x)) {
		case 1:
			sName +=to_string(++count)+ "Programming Fundamentals + Lab\n";
			break;
		case 2:
			sName += to_string(++count) + "Introduction to Computer and Technology Lab\n";
			break;
		case 3:
			sName += to_string(++count) + "English + Lab\n";
			break;
		case 4:
			sName += to_string(++count) + "Linear Algebra\n";
			break;
		case 5:
			sName += to_string(++count) + "Calculus\n";
			break;
		case 6:
			sName += to_string(++count) + "Applied Physics\n";
			break;
		case 7:
			sName += to_string(++count) + "Digital Logic Design\n";
			break;
		case 8:
			sName += to_string(++count) + "Pakistan Studies\n";
			break;
		case 9:
			sName += to_string(++count) + "Islamiyat\n";
			break;
		}
	}
	cout << sName << endl;
}

void Student::ViewFeeStatus(string rollNo,string fee,string name)
{
	cout << endl;
	cout << name << endl;
	cout << rollNo << endl;
	cout << fee << endl;

}

#pragma once

#include<iostream>
#include<fstream>
#include<string>
#include <ctime>
#include<cstdlib>
using namespace std;

class Teacher {
public:

	void Attendance(string str,string course);
	void AssignMarks(string str, string course);
	void AssignGrades(string str, string course);
	void TimeTable(string str, string course);

};
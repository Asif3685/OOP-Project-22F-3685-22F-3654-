#pragma once

#include<iostream>
#include<fstream>
#include<string>
#include <ctime>
using namespace std;

class Student {
public:

	void ViewAttendance(string rollNo, string courses);
	void ViewMarks(string rollNo, string courses);
	void ViewGrades(string rollNo, string courses);
	void ViewCourses(string rollNo, string courses);
	void ViewFeeStatus(string rollNo, string fee, string name);

};